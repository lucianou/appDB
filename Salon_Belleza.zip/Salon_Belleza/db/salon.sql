CREATE TABLE comuna (
    id_comuna int PRIMARY KEY,
    nombre_comuna VARCHAR(30) 
);

CREATE TABLE cliente (
    id_cliente int PRIMARY KEY,
    rut VARCHAR(12) UNIQUE,
    nombre_cliente VARCHAR(100),
    telefono int,
    sexo VARCHAR(20),
    ref_id_comuna INT,
    FOREIGN KEY (ref_id_comuna) REFERENCES comuna(id_comuna)
);

CREATE TABLE cargo (
    id_cargo int PRIMARY KEY,
    nombre_cargo VARCHAR(100)
);

CREATE TABLE salon (
    id_salon int PRIMARY KEY,
    nombre_salon VARCHAR(100),
    direccion VARCHAR(100),
    ref_id_comuna INT,
    FOREIGN KEY (ref_id_comuna) REFERENCES comuna(id_comuna)
);

CREATE TABLE empleado (
    id_empleado int PRIMARY KEY,
    rut VARCHAR(12) UNIQUE,
    nombre_empleado VARCHAR(100),
    telefono int,
    ref_id_comuna INT,
    ref_id_cargo INT,
    FOREIGN KEY (ref_id_comuna) REFERENCES comuna(id_comuna),
    FOREIGN KEY (ref_id_cargo) REFERENCES cargo(id_cargo)
);

CREATE TABLE cliente_salon (
    id_cliente_salon int PRIMARY KEY,
    gasto_mensual INT,
    ref_id_cliente INT,
    ref_id_salon INT,
    FOREIGN KEY (ref_id_cliente) REFERENCES cliente(id_cliente),
    FOREIGN KEY (ref_id_salon) REFERENCES salon(id_salon)
);

CREATE TABLE sueldo (
    id_sueldo int PRIMARY KEY,
    sueldo_por_dia INT,
    dia DATE,
    ref_id_empleado INT,
    FOREIGN KEY (ref_id_empleado) REFERENCES empleado(id_empleado)
);

CREATE TABLE cita (
    id_cita int PRIMARY KEY,
    estado_cita INT,
    horario_ini TIME,
    horario_fin TIME,
    dia date,
    ref_id_empleado INT,
    ref_id_cliente_salon INT,
    ref_id_salon INT,
    FOREIGN KEY (ref_id_empleado) REFERENCES empleado(id_empleado),
    FOREIGN KEY (ref_id_cliente_salon) REFERENCES cliente_salon(id_cliente_salon),
    FOREIGN KEY (ref_id_salon) REFERENCES salon(id_salon)
);

CREATE TABLE productos (
    id_producto int PRIMARY KEY,
    valor_producto INT,
    nombre_producto VARCHAR(100),
    cantidad INT,
    ref_id_salon INT,
    FOREIGN KEY (ref_id_salon) REFERENCES salon(id_salon)
);

CREATE TABLE servicio (
    id_servicio int PRIMARY KEY,
    valor_servicio INT,
    nombre_servicio VARCHAR(100),
    disponible int,
    ref_id_salon INT,
    FOREIGN KEY (ref_id_salon) REFERENCES salon(id_salon)
);

CREATE TABLE boleta (
    id_boleta int PRIMARY KEY,
    monto_pagar INT,
    ref_id_servicio INT,
    ref_id_producto INT,
    ref_id_cita INT,
    FOREIGN KEY (ref_id_servicio) REFERENCES servicio(id_servicio),
    FOREIGN KEY (ref_id_producto) REFERENCES productos(id_producto),
    FOREIGN KEY (ref_id_cita) REFERENCES cita(id_cita)
);

CREATE TABLE pago (
    id_pago int PRIMARY KEY,
    realizado int,
    fecha_pago timestamp,
    tipo_pago VARCHAR(10),
    ref_id_boleta INT,
    FOREIGN KEY (ref_id_boleta) REFERENCES boleta(id_boleta)
);
