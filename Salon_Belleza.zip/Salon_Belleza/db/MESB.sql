-- Dimensiones
CREATE TABLE Dim_Comuna (
    id_comuna int PRIMARY KEY,
    nombre_comuna VARCHAR(100)
);


CREATE TABLE Dim_Cita (
    id_cita int PRIMARY KEY,
    estado_cita INT,
    horario_ini time,
    horario_fin time,
    dia date
);


CREATE TABLE Dim_Salon (
    id_salon int primary key,
    nombre_salon VARCHAR(100),
    direccion VARCHAR(100),
    estado_salon BOOLEAN
);

CREATE TABLE Dim_Cliente (
    id_cliente int primary key,
    rut VARCHAR(12) UNIQUE,
    nombre VARCHAR(100),
    telefono VARCHAR(20),
    sexo VARCHAR(20)
);

CREATE TABLE Dim_Empleado (
    id_empleado int primary key,
    rut VARCHAR(12) UNIQUE,
    nombre VARCHAR(100),
    telefono VARCHAR(20),
    activo BOOLEAN
);

create table Dim_Cargo(
    id_cargo int primary key,
    nombre_cargo VARCHAR(100)
)


CREATE TABLE Dim_Producto (
    id_producto int primary key,
    nombre_producto VARCHAR(100),
    cantidad INT
);

-- Tabla de Hechos: Ventas de Servicios
CREATE TABLE Fact_VentaServicios (
    id_fact int primary key,
    id_salon INT,
    id_cliente INT,
    id_servicio INT,
    id_cita INT,
    nombre_servicio VARCHAR(100),
    valor_servicio INT,
    id_comuna int,
    FOREIGN KEY (id_comuna) REFERENCES Dim_Comuna(id_comuna),
    FOREIGN KEY (id_salon) REFERENCES Dim_Salon(id_salon),
    FOREIGN KEY (id_cliente) REFERENCES Dim_Cliente(id_cliente),
    FOREIGN KEY (id_cita) REFERENCES Dim_Cita(id_cita)
);

-- Tabla de Hechos: Ventas de Productos
CREATE TABLE Fact_VentaProductos (
    id_fact int primary key,
    id_salon INT,
    id_cliente INT,
    id_producto INT,
    valor_producto INT,
    id_comuna INT,
    FOREIGN KEY (id_comuna) REFERENCES Dim_Comuna(id_comuna),
    FOREIGN KEY (id_salon) REFERENCES Dim_Salon(id_salon),
    FOREIGN KEY (id_cliente) REFERENCES Dim_Cliente(id_cliente),
    FOREIGN KEY (id_producto) REFERENCES Dim_Producto(id_producto)
);

-- Tabla de Hechos: Sueldos
CREATE TABLE Fact_Sueldos (
    id_fact int primary key,
    id_salon INT,
    id_empleado INT,
    sueldo_por_dia INT,
    id_comuna INT,
    id_cargo INT,
    FOREIGN KEY (id_cargo) REFERENCES Dim_Cargo(id_cargo),
    FOREIGN KEY (id_comuna) REFERENCES Dim_Comuna(id_comuna),
    FOREIGN KEY (id_salon) REFERENCES Dim_Salon(id_salon),
    FOREIGN KEY (id_empleado) REFERENCES Dim_Empleado(id_empleado)
);
