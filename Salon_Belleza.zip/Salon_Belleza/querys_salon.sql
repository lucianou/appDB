--1
WITH citas_por_horario AS (
SELECT c.ref_id_salon,c.horario_ini,COUNT(*) AS num_citas
FROM cita c
GROUP BY c.ref_id_salon, c.horario_ini),

max_citas_por_salon AS (
SELECT ref_id_salon,MAX(num_citas) AS max_num_citas
FROM citas_por_horario
GROUP BY ref_id_salon)

SELECT s.nombre_salon,sc.nombre_comuna AS comuna_salon,cph.horario_ini AS horario_con_mas_citas,cph.num_citas
FROM citas_por_horario cph
JOIN max_citas_por_salon mcps ON cph.ref_id_salon = mcps.ref_id_salon AND cph.num_citas = mcps.max_num_citas
JOIN salon s ON cph.ref_id_salon = s.id_salon
JOIN comuna sc ON s.ref_id_comuna = sc.id_comuna
ORDER BY cph.num_citas DESC;

--2
WITH 
gasto_cliente AS (
SELECT cs.ref_id_salon,cs.ref_id_cliente,SUM(cs.gasto_mensual) AS total_gasto
FROM cliente_salon cs GROUP BY cs.ref_id_salon, cs.ref_id_cliente),

max_gasto_cliente AS (
SELECT ref_id_salon,MAX(total_gasto) AS max_gasto
FROM gasto_cliente
GROUP BY ref_id_salon)

SELECT c.nombre_cliente,cc.nombre_comuna AS comuna_cliente,s.nombre_salon,sc.nombre_comuna AS comuna_salon, gc.total_gasto
FROM gasto_cliente gc
inner join max_gasto_cliente mgc ON gc.ref_id_salon = mgc.ref_id_salon AND gc.total_gasto = mgc.max_gasto
inner join cliente c ON gc.ref_id_cliente = c.id_cliente
inner join comuna cc ON c.ref_id_comuna = cc.id_comuna
inner join salon s ON gc.ref_id_salon = s.id_salon
inner join comuna sc ON s.ref_id_comuna = sc.id_comuna;

--3
SELECT e.nombre_empleado, EXTRACT(MONTH FROM su.dia) AS mes, SUM(su.sueldo_por_dia) AS ganancia_total
FROM empleado e
JOIN sueldo su ON e.id_empleado = su.ref_id_empleado
WHERE EXTRACT(YEAR FROM su.dia) = 2023
GROUP BY e.nombre_empleado, EXTRACT(MONTH FROM su.dia)
ORDER BY ganancia_total DESC;

--4
select c.nombre_cliente, c.sexo, nombre_servicio
from cliente c 
inner join cliente_salon cp on c.id_cliente  = cp.ref_id_cliente
inner join salon p on cp.ref_id_salon  = p.id_salon 
inner join servicio s on p.id_salon = s.ref_id_salon
where sexo = 'Masculino' and ( nombre_servicio = 'Corte de cabello hombre'or nombre_servicio = 'Corte de Barba');
--5
SELECT cl.nombre_cliente, com_cliente.nombre_comuna AS comuna_cliente, s.nombre_salon AS salon_peluqueria, b.monto_pagar
FROM cliente cl
JOIN cita c ON cl.id_cliente = c.ref_id_cliente_salon
JOIN salon s ON c.ref_id_salon = s.id_salon
JOIN comuna com_cliente ON cl.ref_id_comuna = com_cliente.id_comuna
JOIN boleta b ON c.id_cita = b.ref_id_cita
JOIN servicio se ON b.ref_id_servicio = se.id_servicio
WHERE se.nombre_servicio LIKE '%Tinte%';

--6
SELECT s.nombre_salon AS salon_peluqueria, 
       EXTRACT(YEAR FROM c.dia) AS anio, 
       EXTRACT(MONTH FROM c.dia) AS mes,
       EXTRACT(HOUR FROM c.horario_ini) AS hora_inicio, COUNT(*) AS total_citas
FROM cita c
JOIN salon s ON c.ref_id_salon = s.id_salon
WHERE EXTRACT(YEAR FROM c.dia) IN (2019, 2020)
GROUP BY s.nombre_salon, EXTRACT(YEAR FROM c.dia), EXTRACT(MONTH FROM c.dia), EXTRACT(HOUR FROM c.horario_ini)
ORDER BY total_citas DESC; 
--7
SELECT cl.nombre_cliente, com_cliente.nombre_comuna AS comuna_cliente, s.nombre_salon AS salon_peluqueria, AVG(EXTRACT(EPOCH FROM (c.horario_fin - c.horario_ini))) AS duracion_promedio_segundos
FROM cliente cl
JOIN cita c ON cl.id_cliente = c.ref_id_cliente_salon
JOIN salon s ON c.ref_id_salon = s.id_salon
JOIN comuna com_cliente ON cl.ref_id_comuna = com_cliente.id_comuna
GROUP BY cl.nombre_cliente, com_cliente.nombre_comuna, s.nombre_salon, EXTRACT(MONTH FROM c.dia)
ORDER BY duracion_promedio_segundos DESC;
--8
WITH servicios_max_precio AS (
SELECT ref_id_salon, MAX(valor_servicio) AS max_precio
FROM servicio GROUP BY ref_id_salon
)
SELECT sl.nombre_salon,s.nombre_servicio,s.valor_servicio
FROM  servicios_max_precio AS smp
JOIN servicio AS s ON smp.ref_id_salon = s.ref_id_salon AND smp.max_precio = s.valor_servicio
JOIN  salon AS sl ON s.ref_id_salon = sl.id_salon;

--9
SELECT e.nombre_empleado, EXTRACT(MONTH FROM su.dia) AS mes, SUM(su.sueldo_por_dia) AS sueldo_total
FROM empleado e
JOIN sueldo su ON e.id_empleado = su.ref_id_empleado
WHERE EXTRACT(YEAR FROM su.dia) = 2019
GROUP BY e.nombre_empleado, EXTRACT(MONTH FROM su.dia)
ORDER BY sueldo_total DESC;

--10
SELECT com.nombre_comuna, COUNT(DISTINCT s.id_salon) AS cantidad_peluquerias, COUNT(DISTINCT cl.id_cliente) AS cantidad_clientes
FROM comuna com
LEFT JOIN salon s ON com.id_comuna = s.ref_id_comuna
LEFT JOIN cliente cl ON com.id_comuna = cl.ref_id_comuna
GROUP BY com.nombre_comuna;