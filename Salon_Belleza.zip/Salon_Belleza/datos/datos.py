import random
from faker import Faker
from datetime import datetime


fake = Faker()

# Generación de datos para las tablas
comunas = [
    (1, "Santiago"),
    (2, "Valparaíso"),
    (3, "Concepción"),
    (4, "La Serena"),
    (5, "Antofagasta"),
    (6, "Temuco"),
    (7, "Rancagua"),
    (8, "Puerto Montt"),
    (9, "Chillán"),
    (10, "Talca"),
    (11, "Arica"),
    (12, "Iquique"),
    (13, "Coyhaique"),
    (14, "Punta Arenas"),
    (15, "Calama"),
    (16, "Osorno"),
    (17, "Valdivia"),
    (18, "Copiapó"),
    (19, "Quillota"),
    (20, "Los Ángeles"),
    (21, "Curicó"),
    (22, "San Antonio"),
    (23, "Ovalle"),
    (24, "Linares"),
    (25, "San Fernando"),
    (26, "Melipilla"),
    (27, "Los Andes"),
    (28, "Rengo"),
    (29, "Pudahuel"),
    (30, "Lo Prado"),
    (31, "Independencia"),
    (32, "La Cisterna"),
    (33, "Recoleta"),
    (34, "Quilicura"),
    (35, "El Bosque"),
    (36, "Peñaflor"),
    (37, "Buin"),
    (38, "San Bernardo"),
    (39, "Puente Alto"),
    (40, "La Florida"),
    (41, "Las Condes"),
    (42, "Providencia"),
    (43, "Macul"),
    (44, "Ñuñoa"),
    (45, "Vitacura"),
    (46, "Huechuraba"),
    (47, "Pudahuel"),
    (48, "San Joaquín"),
    (49, "Pedro Aguirre Cerda"),
    (50, "Lo Espejo")
]


cargos = [
    (1, "Peluquero/a"),
    (2, "Estilista"),
    (3, "Manicurista"),
    (4, "Maquillador/a"),
    (5, "Masajista"),
    (6, "Recepcionista"),
    (7, "Gerente de Salón"),
    (8, "Asistente de Salón"),
    (9, "Esteticista"),
    (10, "Asesor/a de Belleza"),
    (11, "Depilador/a"),
    (12, "Barbero/a"),
    (13, "Colorista"),
    (14, "Terapeuta Capilar"),
    (15, "Maestro/a de Corte"),
    (16, "Asistente de Peluquería"),
    (17, "Asistente de Estilista"),
    (18, "Asistente de Manicura"),
    (19, "Especialista en Tratamientos Faciales"),
    (20, "Especialista en Tratamientos Corporales")
]



productos = [
    (1, 15000, "Shampoo para cabello seco", 50, random.randint(1, 50)),
    (2, 12000, "Acondicionador revitalizante", 40, random.randint(1, 50)),
    (3, 25000, "Tratamiento capilar hidratante", 30, random.randint(1, 50)),
    (4, 18000, "Gel para peinado natural", 60, random.randint(1, 50)),
    (5, 20000, "Aceite reparador de puntas", 45, random.randint(1, 50)),
    (6, 30000, "Mascarilla nutritiva para cabello", 35, random.randint(1, 50)),
    (7, 22000, "Crema para manos y uñas", 55, random.randint(1, 50)),
    (8, 28000, "Spray fijador de peinados", 50, random.randint(1, 50)),
    (9, 35000, "Aceite esencial para masajes", 25, random.randint(1, 50)),
    (10, 18000, "Esmalte de uñas de larga duración", 70, random.randint(1, 50)),
    (11, 40000, "Set de maquillaje profesional", 20, random.randint(1, 50)),
    (12, 32000, "Cera depilatoria suave", 40, random.randint(1, 50)),
    (13, 25000, "Kit para manicure y pedicure", 30, random.randint(1, 50)),
    (14, 30000, "Máscara facial revitalizante", 25, random.randint(1, 50)),
    (15, 28000, "Serum anti-edad para el rostro", 35, random.randint(1, 50)),
    (16, 22000, "Exfoliante corporal natural", 50, random.randint(1, 50)),
    (17, 18000, "Protector solar FPS 50+", 60, random.randint(1, 50)),
    (18, 25000, "Perfume de fragancia floral", 40, random.randint(1, 50)),
    (19, 30000, "Sales de baño relajantes", 30, random.randint(1, 50)),
    (20, 35000, "Cepillo alisador iónico", 25, random.randint(1, 50)),
    (21, 18000, "Esponja facial limpiadora", 70, random.randint(1, 50)),
    (22, 40000, "Afeitadora eléctrica para hombres", 20, random.randint(1, 50)),
    (23, 32000, "Gel refrescante para piernas cansadas", 40, random.randint(1, 50)),
    (24, 25000, "Lima eléctrica para pies", 30, random.randint(1, 50)),
    (25, 30000, "Cepillo voluminizador para cabello", 25, random.randint(1, 50)),
    (26, 28000, "Bálsamo labial nutritivo", 35, random.randint(1, 50)),
    (27, 22000, "Tinte semi-permanente para cabello", 50, random.randint(1, 50)),
    (28, 18000, "Ampolla reparadora post-sol", 60, random.randint(1, 50)),
    (29, 25000, "Spray brillo instantáneo", 40, random.randint(1, 50)),
    (30, 30000, "Toalla turban para secado rápido", 30, random.randint(1, 50)),
    (31, 35000, "Pestañas postizas efecto natural", 25, random.randint(1, 50)),
    (32, 18000, "Kit de peines profesionales", 70, random.randint(1, 50)),
    (33, 40000, "Removedor de esmalte sin acetona", 20, random.randint(1, 50)),
    (34, 32000, "Aceite de coco multiusos", 40, random.randint(1, 50)),
    (35, 25000, "Máquina eléctrica para tratamientos faciales", 30, random.randint(1, 50)),
    (36, 30000, "Tónico facial purificante", 25, random.randint(1, 50)),
    (37, 28000, "Cepillo masajeador anticelulítico", 35, random.randint(1, 50)),
    (38, 22000, "Espejo de aumento con luz LED", 50, random.randint(1, 50)),
    (39, 18000, "Difusor de aceites esenciales", 60, random.randint(1, 50)),
    (40, 25000, "Set de brochas de maquillaje veganas", 40, random.randint(1, 50)),
    (41, 30000, "Gorro térmico para tratamientos capilares", 30, random.randint(1, 50)),
    (42, 35000, "Lámpara UV para secado de uñas", 25, random.randint(1, 50)),
    (43, 18000, "Bálsamo acondicionador de cejas", 70, random.randint(1, 50)),
    (44, 40000, "Spray hidratante para piel sensible", 20, random.randint(1, 50)),
    (45, 32000, "Gel calmante para irritaciones cutáneas", 40, random.randint(1, 50)),
    (46, 25000, "Esmalte gel de larga duración", 30, random.randint(1, 50)),
    (47, 30000, "Máscara para pestañas waterproof", 25, random.randint(1, 50)),
    (48, 28000, "Aceite nutritivo para cutículas", 35, random.randint(1, 50)),
    (49, 22000, "Perfume masculino con aroma amaderado", 50, random.randint(1, 50)),
    (50, 18000, "Aparato eléctrico para depilación facial", 60, random.randint(1, 50)),
]

servicios = [
    (1, 15000, "Corte de cabello hombre", 0, 1),
    (2, 12000, "Corte de Barba", 0, 2),
    (3, 25000, "Corte de cabello moderno", 0, 3),
    (4, 18000, "Manicure y pedicure básicos", 0, 4),
    (5, 20000, "Depilación con cera", 0, 5),
    (6, 30000, "Maquillaje profesional", 0, 6),
    (7, 22000, "Tratamiento capilar hidratante", 0, 7),
    (8, 28000, "Pedicure spa", 0, 8),
    (9, 35000, "Masaje de tejido profundo", 0, 9),
    (10, 18000, "Tinte de cabello", 0, 10),
    (11, 40000, "Peinado para eventos", 0, 11),
    (12, 32000, "Tratamiento de uñas acrílicas", 0, 12),
    (13, 25000, "Exfoliación corporal", 0, 13),
    (14, 30000, "Maquillaje de novia", 0, 14),
    (15, 28000, "Tratamiento facial anti-acné", 0, 15),
    (16, 22000, "Corte de barba y bigote", 0, 16),
    (17, 18000, "Manicure francesa", 0, 17),
    (18, 25000, "Limpieza facial profunda", 0, 18),
    (19, 30000, "Reflejos en cabello largo", 0, 19),
    (20, 35000, "Masaje de pies y piernas", 0, 20),
    (21, 18000, "Tinte de cejas", 0, 21),
    (22, 40000, "Peinado con ondas", 0, 22),
    (23, 32000, "Tratamiento de keratina", 0, 23),
    (24, 25000, "Baño de color para cabello", 0, 24),
    (25, 30000, "Tratamiento anti-frizz", 0, 25),
    (26, 28000, "Manicure spa", 0, 26),
    (27, 22000, "Facial masculino revitalizante", 0, 27),
    (28, 18000, "Pedicure con esmalte de larga duración", 0, 28),
    (29, 25000, "Tratamiento de rejuvenecimiento facial", 0, 29),
    (30, 30000, "Retoque de raíces", 0, 30),
    (31, 35000, "Masaje de espalda y hombros", 0, 31),
    (32, 18000, "Diseño de cejas", 0, 32),
    (33, 40000, "Peinado recogido", 0, 33),
    (34, 32000, "Mascarilla capilar nutritiva", 0, 34),
    (35, 25000, "Tratamiento de hidratación facial", 0, 35),
    (36, 30000, "Tratamiento de ondulado permanente", 0, 36),
    (37, 28000, "Depilación facial", 0, 37),
    (38, 22000, "Masaje craneal", 0, 38),
    (39, 18000, "Pedicure spa con parafina", 0, 39),
    (40, 25000, "Tratamiento anti-edad", 0, 40),
    (41, 30000, "Tinte fantasia para el cabello", 0, 41),
    (42, 35000, "Masaje tailandés", 0, 42),
    (43, 18000, "Decoración de uñas", 0, 43),
    (44, 40000, "Peinado para novia", 0, 44),
    (45, 32000, "Tratamiento de botox capilar", 0, 45),
    (46, 25000, "Tratamiento facial con vitamina C", 0, 46),
    (47, 30000, "Mascarilla de oro facial", 0, 47),
    (48, 28000, "Manicure clásica", 0, 48),
    (49, 22000, "Masaje de relajación profunda", 0, 49),
    (50, 18000, "Refuerzo de queratina", 0, 50),
]

def generate_random_date(start_date, end_date):
    if isinstance(start_date, str):
        start_date = datetime.strptime(start_date, '%Y-%m-%d')
    if isinstance(end_date, str):
        end_date = datetime.strptime(end_date, '%Y-%m-%d')
    return fake.date_time_between_dates(datetime_start=start_date, datetime_end=end_date).date()

def generar_horario_inicial():
    # Genera un horario inicial aleatorio en intervalos de media hora
    hora_inicial = random.randint(8, 20)  # Entre las 08:00 y las 20:00 horas
    minutos_iniciales = random.choice([0, 30])  # En intervalos de media hora
    return f"{hora_inicial:02}:{minutos_iniciales:02}:00"

def generar_horario_final(horario_inicial):
    # Calcula un horario final dentro de las dos horas posteriores al inicial
    hora_inicial = int(horario_inicial[:2])
    minutos_iniciales = int(horario_inicial[3:5])

    # Calcula el horario final en intervalos de media hora hasta 2 horas después
    hora_final = hora_inicial + random.randint(1, 4)  # 1 a 4 intervalos de media hora (1 a 2 horas)
    minutos_finales = minutos_iniciales + random.choice([0, 30])  # En intervalos de media hora

    # Asegura que el horario final no exceda las 22:00 horas
    if hora_final > 22:
        hora_final = 22
        minutos_finales = 0

    return f"{hora_final:02}:{minutos_finales:02}:00"


# Clientes
def generate_rut():
    rut_number = random.randint(1000000, 25000000)
    rut_str = f"{rut_number:,}".replace(",", ".")
    verification_digit = calculate_verification_digit(rut_number)
    return f"{rut_str}-{verification_digit}"

def calculate_verification_digit(rut_number):
    reversed_digits = map(int, reversed(str(rut_number)))
    factors = cycle(range(2, 8))
    s = sum(d * f for d, f in zip(reversed_digits, factors))
    verification_digit = (-s) % 11
    return 'K' if verification_digit == 10 else str(verification_digit)

def cycle(iterable):
    while True:
        for item in iterable:
            yield item

def generate_cliente_data(cliente_id):
    rut_cliente = generate_rut()
    nombre_cliente = fake.name()
    telefono = '9' + str(fake.random_int(min=10000000, max=99999999))
    sexo = random.choice(['Masculino', 'Femenino'])
    ref_id_comuna = random.randint(1, 50)  # Ajustar según la cantidad de localidades
    return cliente_id, rut_cliente, nombre_cliente, telefono, sexo, ref_id_comuna

# empleados
def generate_empleado_data(empleado_id):
    rut = generate_rut()
    nombre_empleado = fake.name()
    telefono = '9' + str(fake.random_int(min=10000000, max=99999999))
    ref_id_comuna = random.randint(1, 50)  # Ajustar según la cantidad de localidades
    ref_id_cargo  = random.randint(1, 20)
    return empleado_id, rut, nombre_empleado, telefono, ref_id_comuna, ref_id_cargo

# Postes
def generate_cliente_salon_data(cliente_salon_id):
    gasto_mensual = fake.random_int(min=10000000, max=99999999)
    ref_id_cliente = random.randint(1, 1000)
    ref_id_salon = random.randint(1, 100)
    return cliente_salon_id, gasto_mensual, ref_id_cliente, ref_id_salon

def generate_sueldo_data(sueldo_id):
    start_date = '2019-01-01'
    end_date = '2023-12-31'
    random_date = generate_random_date(start_date, end_date)
    sueldo_por_dia = random.uniform(20000, 50000)
    dia = random_date
    ref_id_empleado = random.randint(1, 500)
    return sueldo_id, sueldo_por_dia, dia, ref_id_empleado


# Proveer
def generate_salon_data(salon_id):
    nombre_salon = fake.company()
    direccion = fake.address()
    ref_id_comuna = random.randint(1,50)
    return salon_id, nombre_salon, direccion,ref_id_comuna

start_date = '2019-01-01'
end_date = '2023-12-31'
def generate_cita_data(cita_id):
    estado_cita = random.choice([0,1])
    horario_ini = generar_horario_inicial()
    horario_fin = generar_horario_final(horario_ini)
    random_date = generate_random_date(start_date, end_date)
    dia =  random_date.strftime("%d-%m-%Y")
    ref_id_empleado = random.randint(1,500)
    ref_id_cliente_salon = random.randint(1,1000)
    ref_id_salon = random.randint(1,50)
    return cita_id, estado_cita, horario_ini,horario_fin,dia,ref_id_empleado,ref_id_cliente_salon,ref_id_salon

# Boletas
def generate_boleta_data(boleta_id):
    monto_pagar = random.randint(5000, 50000)
    ref_id_servicio = random.randint(1,50)
    ref_id_producto = random.randint(1,50)
    ref_id_cita = random.randint(1,1000)
    return boleta_id, monto_pagar, ref_id_servicio, ref_id_producto, ref_id_cita

start_date = '2019-01-01'
end_date = '2023-12-31'
def generate_pago_data(pago_id):
    realizado = random.choice([0,1])
    random_date = generate_random_date(start_date, end_date)
    fecha_pago =  random_date.strftime("%d-%m-%Y")
    tipo_pago = random.choice(['Credito','Debito','Efectivo'])
    ref_id_boleta = random.randint(1,1000)
    return pago_id,realizado, fecha_pago, tipo_pago, ref_id_boleta
# Generación de INSERTs para las tablas
def generate_insert_queries():
    queries = []
    cliente_id = 1
    empleado_id = 1
    cliente_salon_id = 1
    salon_id = 1
    sueldo_id = 1
    cita_id = 1
    boleta_id = 1
    pago_id = 1
    

    for comuna in comunas:
        id_comuna, nombre_comuna = comuna
        queries.append(f"INSERT INTO comuna (id_comuna, nombre_comuna) "
                       f"VALUES ({id_comuna}, '{nombre_comuna}');")
    
    for _ in range(1000):
        cliente_id, rut_cliente, nombre_cliente, telefono, sexo, ref_id_comuna = generate_cliente_data(cliente_id)
        queries.append(f"INSERT INTO cliente (id_cliente, rut, nombre_cliente, telefono, sexo, ref_id_comuna) "
                       f"VALUES ({cliente_id},'{rut_cliente}', '{nombre_cliente}', '{telefono}', '{sexo}', {ref_id_comuna});")
        cliente_id += 1

    for cargo in cargos:
        id_cargo, nombre_cargo = cargo
        queries.append(f"INSERT INTO cargo (id_cargo, nombre_cargo) "
                   f"VALUES ({id_cargo}, '{nombre_cargo}');")
        

    for _ in range(500):
        empleado_id, rut, nombre_empleado, telefono, ref_id_comuna, ref_id_cargo = generate_empleado_data(empleado_id)
        queries.append(f"INSERT INTO empleado (id_empleado, rut, nombre_empleado, telefono, ref_id_comuna, ref_id_cargo) "
                       f"VALUES ({empleado_id},'{rut}','{nombre_empleado}', {telefono}, {ref_id_comuna}, {ref_id_cargo});")
        empleado_id += 1
    
    for _ in range(100):
        salon_id, nombre_salon, direccion,ref_id_comuna = generate_salon_data(salon_id)
        queries.append(f"INSERT INTO salon (id_salon, nombre_salon, direccion,ref_id_comuna) "
                       f"VALUES ({salon_id}, '{nombre_salon}', '{direccion}',{ref_id_comuna});")
        salon_id += 1

    for _ in range(1000):
        cliente_salon_id, gasto_mensual, ref_id_cliente, ref_id_salon= generate_cliente_salon_data(cliente_salon_id)
        queries.append(f"INSERT INTO cliente_salon (id_cliente_salon, gasto_mensual, ref_id_cliente, ref_id_salon ) "
                       f"VALUES ({cliente_salon_id},{gasto_mensual},{ref_id_cliente},{ref_id_salon});")
        cliente_salon_id += 1

    for _ in range(500):
        sueldo_id, sueldo_por_dia, dia, ref_id_empleado = generate_sueldo_data(sueldo_id)
        queries.append(f"INSERT INTO sueldo (id_sueldo, sueldo_por_dia, dia, ref_id_empleado) "
                       f"VALUES ({sueldo_id}, {sueldo_por_dia}, '{dia}', {ref_id_empleado});")
        sueldo_id += 1

    for _ in range(1000):
        cita_id, estado_cita, horario_ini,horario_fin,dia,ref_id_empleado,ref_id_cliente_salon,ref_id_salon = generate_cita_data(cita_id)
        queries.append(f"INSERT INTO cita (id_cita, estado_cita, horario_ini,horario_fin,dia, ref_id_empleado,ref_id_cliente_salon,ref_id_salon) "
                       f"VALUES ({cita_id}, {estado_cita}, '{horario_ini}', '{horario_fin}','{dia}',{ref_id_empleado},{ref_id_cliente_salon},{ref_id_salon});")
        cita_id += 1

    for producto in productos:
        id_producto, valor_producto,nombre_producto,cantidad,ref_id_salon = producto
        queries.append(f"INSERT INTO productos (id_producto, valor_producto, nombre_producto,cantidad,ref_id_salon) "
                   f"VALUES ({id_producto}, {valor_producto}, '{nombre_producto}',{cantidad},{ref_id_salon});")
    
    for servicio in servicios:
        id_servicio, valor_servicio, nombre_servicio, disponible, ref_id_salon = servicio
        queries.append(f"INSERT INTO servicio (id_servicio, valor_servicio, nombre_servicio, disponible, ref_id_salon) "
                   f"VALUES ({id_servicio},{valor_servicio},'{nombre_servicio}',{disponible},{ref_id_salon});")

    for _ in range(1000):
        boleta_id, monto_pagar, ref_id_servicio, ref_id_producto, ref_id_cita = generate_boleta_data(boleta_id)
        queries.append(f"INSERT INTO boleta (id_boleta, monto_pagar, ref_id_servicio, ref_id_producto, ref_id_cita) "
                       f"VALUES ({boleta_id}, {monto_pagar}, {ref_id_servicio}, {ref_id_producto}, {ref_id_cita});")
        boleta_id += 1
    for _ in range(1000):
        pago_id, realizado, fecha_pago, tipo_pago, ref_id_boleta= generate_pago_data(pago_id)
        queries.append(f"INSERT INTO pago (id_pago, realizado, fecha_pago, tipo_pago, ref_id_boleta) "
                       f"VALUES ({pago_id}, {realizado}, '{fecha_pago}', '{tipo_pago}', {ref_id_boleta});")
        pago_id += 1
    
    return queries

# Generar y guardar consultas INSERT en un archivo SQL
insert_queries = generate_insert_queries()
with open('datos_salon.sql', 'w') as f:
    for query in insert_queries:
        f.write(query + '\n')