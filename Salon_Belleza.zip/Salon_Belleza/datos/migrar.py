import os
import schedule
import time
import psycopg2
import sys
from dotenv import load_dotenv

load_dotenv()  # cargar variables de entorno

intervalo = int(os.getenv("INTERVAL"))
mensaje = os.getenv("MESSAGE")
user = os.getenv("user")
host = os.getenv("host")
port = os.getenv("port")
password = os.getenv("password")
base_antigua = os.getenv("base_antigua")
base_nueva = os.getenv("base_nueva")

def conectarPostgres(db, host_ip, usuario, contrasena, puerto):
    try:
        conn = psycopg2.connect(database=db,
                                host=host_ip,
                                user=usuario,
                                password=contrasena,
                                port=puerto,
                                options="-c client_encoding=utf8")
        print("Conexión exitosa a PostgreSQL")
    except psycopg2.Error as e:
        print(f"Error al conectar a PostgreSQL: {e}")
        sys.exit(1)
    return conn

conn_old = conectarPostgres(base_antigua, host, user, password, port)
conn_new = conectarPostgres(base_nueva, host, user, password, port)

cursor_old = conn_old.cursor()
cursor_new = conn_new.cursor()

# Función para traspasar datos de una tabla
def transfer_data(query_select, query_insert, transform_fn=None):
    cursor_old.execute(query_select)
    rows = cursor_old.fetchall()
    print(len(rows))
    for row in rows:
        if transform_fn:
            row = transform_fn(row)
        cursor_new.execute(query_insert, row)

# Migración de tablas de dimensiones
# comuna
transfer_data(
    "SELECT id_comuna, nombre_comuna FROM public.comuna",
    "INSERT INTO public.dim_comuna (id_comuna, nombre_comuna) VALUES (%s, %s)"
)
# cita
transfer_data(
    "SELECT id_cita, estado_cita, horario_ini, horario_fin, dia FROM public.cita",
    "INSERT INTO public.dim_cita (id_cita, estado_cita, horario_ini, horario_fin, dia) VALUES (%s, %s, %s, %s, %s)"
)
# salon
transfer_data(
    "SELECT id_salon, nombre_salon, direccion FROM public.salon",
    "INSERT INTO public.dim_salon (id_salon, nombre_salon, direccion) VALUES (%s, %s, %s)"
)
# cliente
transfer_data(
    "SELECT id_cliente, rut, nombre_cliente, telefono, sexo FROM public.cliente",
    "INSERT INTO public.dim_cliente (id_cliente, rut, nombre, telefono, sexo) VALUES (%s, %s, %s, %s, %s)"
)
# empleado
transfer_data(
    "SELECT id_empleado, rut, nombre_empleado, telefono, TRUE FROM public.empleado",
    "INSERT INTO public.dim_empleado (id_empleado, rut, nombre, telefono, activo) VALUES (%s, %s, %s, %s, %s)"
)
# cargo
transfer_data(
    "SELECT id_cargo, nombre_cargo FROM public.cargo",
    "INSERT INTO public.dim_cargo (id_cargo, nombre_cargo) VALUES (%s, %s)"
)
# producto
transfer_data(
    "SELECT id_producto, nombre_producto, cantidad FROM public.productos",
    "INSERT INTO public.dim_producto (id_producto, nombre_producto, cantidad) VALUES (%s, %s, %s)"
)

# Migración de tablas de hechos
# Fact_VentaServicios
transfer_data(
    """
    SELECT 
        b.id_boleta, 
        c.ref_id_salon, 
        cs.ref_id_cliente, 
        b.ref_id_servicio, 
        c.id_cita, 
        s.nombre_servicio, 
        s.valor_servicio, 
        sl.ref_id_comuna 
    FROM boleta b
    JOIN cita c ON b.ref_id_cita = c.id_cita
    JOIN cliente_salon cs ON c.ref_id_cliente_salon = cs.id_cliente_salon
    JOIN servicio s ON b.ref_id_servicio = s.id_servicio
    JOIN salon sl ON s.ref_id_salon = sl.id_salon;
    """,
    """
    INSERT INTO public.fact_ventaservicios (id_fact, id_salon, id_cliente, id_servicio, id_cita, nombre_servicio, valor_servicio, id_comuna)
    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
    """
)

# Fact_VentaProductos
transfer_data(
    """
    SELECT 
        b.id_boleta, 
        p.ref_id_salon, 
        cs.ref_id_cliente, 
        b.ref_id_producto, 
        p.valor_producto, 
        sl.ref_id_comuna 
    FROM boleta b
    JOIN productos p ON b.ref_id_producto = p.id_producto
    JOIN cita c ON b.ref_id_cita = c.id_cita
    JOIN cliente_salon cs ON c.ref_id_cliente_salon = cs.id_cliente_salon
    JOIN salon sl ON p.ref_id_salon = sl.id_salon;
    """,
    """
    INSERT INTO public.fact_ventaproductos (id_fact, id_salon, id_cliente, id_producto, valor_producto, id_comuna)
    VALUES (%s, %s, %s, %s, %s, %s)
    """
)

# Fact_Sueldos
transfer_data(
    """
    SELECT 
        s.id_sueldo, 
        e.ref_id_comuna, 
        s.ref_id_empleado, 
        s.sueldo_por_dia, 
        e.ref_id_comuna, 
        e.ref_id_cargo 
    FROM sueldo s
    JOIN empleado e ON s.ref_id_empleado = e.id_empleado;
    """,
    """
    INSERT INTO public.fact_sueldos (id_fact, id_salon, id_empleado, sueldo_por_dia, id_comuna, id_cargo)
    VALUES (%s, %s, %s, %s, %s, %s)
    """
)

# Confirmar cambios en la base de datos nueva
conn_new.commit()

# Cerrar cursores y conexiones
cursor_new.close()
conn_old.close()
conn_new.close()

while True:
    schedule.run_pending()
    time.sleep(intervalo)
